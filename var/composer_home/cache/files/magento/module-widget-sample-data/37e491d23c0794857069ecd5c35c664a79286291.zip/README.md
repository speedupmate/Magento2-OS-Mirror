Magento_WidgetSampleData module consists of installation scripts and fixtures.
